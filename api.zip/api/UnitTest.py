import unittest

R1 = "/api/ping"
R2 = "/api/posts"


def test_200_ping(self):
    response = self.client().get(R1)
    self.assertEqual(response.status_code, 200)
    self.assertTrue(response.json["success"])


def test_400_no_tag(self):
    response = self.client().get(R2 + "")
    self.assertEqual(response.status_code, 400)
    self.assertEqual(response.json["error"], "Tags parameter is required")


def test_200_one_query(self):
    response = self.client().get(R2 + "?tags=health")
    self.assertEqual(response.status_code, 200)
    self.assertTrue(response.json["posts"])
    for post in response.json["posts"]:
        self.assertTrue("health" in post["tags"])


def test_200_two_query(self):
    response = self.client().get(R2 + "?tags=health,tech")
    self.assertEqual(response.status_code, 200)
    self.assertTrue(response.json["posts"])
    for post in response.json["posts"]:
        self.assertTrue("health" in post["tags"] or "tech" in post["tags"])


def test_200_sort(self):
    response = self.client().get(R2 + "?tags=health" + "&sortBy=likes")
    self.assertEqual(response.status_code, 200)
    prev, curr = 0, 0
    for post in response.json["posts"]:
        self.assertTrue("health" in post["tags"])
        curr = post["likes"]
        self.assertTrue(curr >= prev)
        prev = curr


def test_400_bad_sort_key(self):
    response = self.client().get(R2 + "?tags=health" + "&sortBy=xyz")
    self.assertEqual(response.status_code, 400)
    self.assertEqual(response.json["error"], "sortBy parameter is invalid")


if __name__ == "__main__":
    unittest.main()
