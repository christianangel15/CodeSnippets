import requests
from flask import Flask, jsonify, request
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)


class ping(Resource):
    def get(self):
        data = {
            "success": True
        }
        response = jsonify(data)
        response.status_code = 200
        return response


class blog(Resource):
    def get(self):
        tag_required = {"error": "Tags parameter is mandatory"}
        sortby_error = {"error": "sortBy parameter is invalid"}
        direction_error = {"error": "direction parameter is invalid"}
        misc_error = {
            "error": "Unknown error."}

        tagsStr = request.args.get("tags", None, str)
        if tagsStr is None:
            return tag_required, 400

        sort_by = request.args.get("sortBy", "id")
        if sort_by not in ["id", "reads", "likes", "popularity"]:
            return sortby_error, 400

        direction = request.args.get("direction", "asc")
        if direction not in ["asc", "desc"]:
            return direction_error, 400

        tags = tagsStr.strip().lower().split(",")
        try:
            AllPosts = []
            for tag in tags:
                resp = requests.get(
                    f"https://hatchways.io/api/assessment/blog/posts?tag={tag}"
                ).json()
                AllPosts += resp["posts"]

            # print(len(AllPosts))
            result = [i for n, i in enumerate(
                AllPosts) if i not in AllPosts[n + 1:]]
            is_reverse = True if direction == "desc" else False
            result = sorted(
                result, key=lambda x: x[sort_by], reverse=is_reverse)

            return {"posts": result}, 200

        except:
            return misc_error, 400


api.add_resource(ping, "/api/ping")
api.add_resource(blog, "/api/posts")
app.run(host='localhost', port=8080, debug=True)
